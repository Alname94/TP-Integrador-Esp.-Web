package ar.edu.centro8.daw.services.interfaces;

import java.util.List;

import ar.edu.centro8.daw.models.Presupuesto;

public interface IPresupuestoService {

    public List<Presupuesto> getPresupuestos();

    public Presupuesto savePresupuesto(Presupuesto presupuesto);

    public Presupuesto getPresupuestoById(Long numero);

    public void deletePresupuesto(Long numero);

    public Presupuesto editPresupuesto(Presupuesto presupuesto);

    public List<Presupuesto> findByClienteNombreContainingIgnoreCaseOrBicicletaMarcaContainingIgnoreCase(String query, String query2);

    public List<Presupuesto> findByBicicletaId(Long bicicletaId);
}
