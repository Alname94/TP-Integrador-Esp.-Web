package ar.edu.centro8.daw.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ar.edu.centro8.daw.models.Detalle;
import ar.edu.centro8.daw.models.DetalleId;

@Repository
public interface IDetalleRepository extends JpaRepository<Detalle, DetalleId>{
    
    List<Detalle> findByPresupuestoNumero(Long presupuestoNumero);
}
