package ar.edu.centro8.daw.services.interfaces;

import java.util.List;
import java.util.Optional;

import ar.edu.centro8.daw.models.Cliente;

public interface IClienteService {

    public List<Cliente> getClientes();

    public Cliente saveCliente(Cliente cliente);

    public void deleteCliente(Long id);

    public Cliente findCliente(Long id);

    public Cliente editCliente(Cliente cliente);

    public List<Cliente> findByNombreContainingIgnoreCase(String nombre);

    public Optional<Cliente> findByDni(String dni);

}
