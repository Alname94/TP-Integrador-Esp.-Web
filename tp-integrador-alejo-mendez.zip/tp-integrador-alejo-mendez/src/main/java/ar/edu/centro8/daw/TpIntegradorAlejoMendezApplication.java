package ar.edu.centro8.daw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpIntegradorAlejoMendezApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpIntegradorAlejoMendezApplication.class, args);
	}

}
