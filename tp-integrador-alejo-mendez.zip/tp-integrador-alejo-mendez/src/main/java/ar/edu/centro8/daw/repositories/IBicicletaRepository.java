package ar.edu.centro8.daw.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ar.edu.centro8.daw.models.Bicicleta;

@Repository
public interface IBicicletaRepository extends JpaRepository<Bicicleta, Long>{

    List<Bicicleta> findByMarcaContainingIgnoreCase(String marca);

    List<Bicicleta> findByClienteId(Long clienteId);

    List<Bicicleta> findByFechaEgresoIsNull();
}
