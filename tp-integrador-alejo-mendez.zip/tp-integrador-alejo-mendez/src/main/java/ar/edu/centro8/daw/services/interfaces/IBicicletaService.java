package ar.edu.centro8.daw.services.interfaces;

import java.util.List;

import ar.edu.centro8.daw.models.Bicicleta;

public interface IBicicletaService {

    public List<Bicicleta> getBicicletas();

    public Bicicleta saveBicicleta(Bicicleta bicicleta);

    public void deleteBicicleta(Long id);

    public Bicicleta getBicicleta(Long id);

    public Bicicleta editBicicleta(Bicicleta bicicleta);

    public List<Bicicleta> findByMarcaContainingIgnoreCase(String marca);

    public List<Bicicleta> findByClienteId(Long clienteId);

    public List<Bicicleta> findByFechaEgresoIsNull();

}
