package ar.edu.centro8.daw.services.interfaces;

import java.util.List;

import ar.edu.centro8.daw.models.Repuesto;

public interface IRepuestoService {

    public List<Repuesto> getRepuestos();

    public Repuesto saveRepuesto(Repuesto repuesto);

    public void deleteRepuesto(Long codigo);

    public Repuesto getRepuesto(Long codigo);

    public Repuesto editRepuesto(Repuesto repuesto);

    List<Repuesto> findByProductoContainingIgnoreCaseOrMarcaContainingIgnoreCase(String producto, String marca);

}
