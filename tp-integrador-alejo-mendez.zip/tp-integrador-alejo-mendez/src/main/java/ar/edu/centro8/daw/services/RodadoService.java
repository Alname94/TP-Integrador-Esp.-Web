package ar.edu.centro8.daw.services;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import ar.edu.centro8.daw.models.enums.Rodado;
import ar.edu.centro8.daw.services.interfaces.IRodadoService;

@Service
public class RodadoService implements IRodadoService {

    @Override
    public List<String> obtenerValoresRodado() {
        return Arrays.stream(Rodado.values())
                     .map(Rodado::getValorAsociado)
                     .collect(Collectors.toList());
    }

}
