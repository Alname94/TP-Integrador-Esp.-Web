package ar.edu.centro8.daw.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import ar.edu.centro8.daw.models.Repuesto;

@Repository
public interface IRepuestoRepository extends JpaRepository<Repuesto, Long>{

    List<Repuesto> findByProductoContainingIgnoreCaseOrMarcaContainingIgnoreCase(String query, String query2);

    boolean existsById(Long codigo);
}
