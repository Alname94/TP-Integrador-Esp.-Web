package ar.edu.centro8.daw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpIntegradorAlejoMendezApplicationTests {

	@Test
	void contextLoads() {
	}

}
